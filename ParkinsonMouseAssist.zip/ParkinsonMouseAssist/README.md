# ParkinsonMouseAssist 🖱️

Software de assistência ao uso do mouse para pessoas com doença de Parkinson.  
Utiliza **Inteligência Artificial (Filtro de Kalman 2D com camada adaptativa)** para filtrar
os tremores involuntários do mouse em tempo real.

---

## 📋 Requisitos

- Windows 10 ou 11
- [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0)
- Visual Studio 2022 (Community é gratuito) **ou** VS Code com extensão C#

---

## 🚀 Como compilar e executar

### Via Visual Studio 2022
1. Abra o arquivo `ParkinsonMouseAssist.sln` (ou abra a pasta pelo menu File → Open Folder)
2. Pressione **F5** para compilar e executar

### Via linha de comando
```bash
cd ParkinsonMouseAssist
dotnet run
```

### Gerar executável
```bash
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true
```
O executável estará em `bin/Release/net8.0-windows/win64/publish/`

---

## 🧠 Arquitetura de IA — Filtro de Kalman 2D Adaptativo

### Por que Filtro de Kalman?

O **Filtro de Kalman** é um algoritmo de estimação ótima amplamente usado em IA,
robótica e veículos autônomos. É ideal para este problema porque:

- Funciona em **tempo real** com latência imperceptível
- **Modela probabilisticamente** a posição "intencional" do usuário
- **Separa** o movimento voluntário do tremor involuntário
- Academicamente sólido e bem documentado

### Modelo matemático

O sistema mantém um **estado oculto** do cursor:

```
Estado = [x, y, velocidade_x, velocidade_y]
```

A cada evento de mouse, executa dois passos:

```
1. PREDIÇÃO:   "Onde o cursor deve estar com base no movimento anterior?"
   x_pred = F · x_anterior

2. ATUALIZAÇÃO: "Incorporar a medição ruidosa (com tremor) de forma ótima."
   Ganho de Kalman K = P · H' · (H·P·H' + R)^-1
   x_novo = x_pred + K · (medição - x_pred)
```

### Camada adaptativa

O `AdaptiveTremorFilter` analisa uma **janela deslizante** de 60 eventos para:

1. **Detectar o nível de tremor** via variância + taxa de oscilação
2. **Ajustar dinamicamente** os parâmetros do Kalman:
   - `processNoise` (Q): quanto o modelo confia na previsão
   - `measurementNoise` (R): quanto o modelo confia nas medições

Quanto mais tremor detectado → maior R → o filtro ignora mais as medições ruidosas.

### Parâmetros ajustáveis

| Parâmetro | Efeito |
|-----------|--------|
| Filtro Suave (0%) | Passa a maior parte dos movimentos, mínima filtragem |
| Filtro Médio (50%) | Equilibrio entre suavidade e responsividade |
| Filtro Máximo (100%) | Filtragem intensa, cursor muito suave |

---

## 📁 Estrutura do projeto

```
ParkinsonMouseAssist/
├── Core/
│   ├── KalmanFilter2D.cs        ← Implementação matemática do Filtro de Kalman
│   ├── AdaptiveTremorFilter.cs  ← Camada adaptativa + detecção de tremor
│   ├── MouseHook.cs             ← Hook de baixo nível Win32 (WH_MOUSE_LL)
│   └── StartupManager.cs        ← Registro do Windows para inicialização
├── Models/
│   └── AppSettings.cs           ← Configurações persistidas em JSON
├── MainWindow.xaml              ← Interface WPF
├── MainWindow.xaml.cs           ← Lógica da interface
└── App.xaml / App.xaml.cs       ← Ponto de entrada da aplicação
```

---

## 🔧 Como funciona o hook de mouse

O `MouseHook` instala um **Low-Level Mouse Hook** (WH_MOUSE_LL) do Windows:

```
Movimento físico do mouse
        ↓
  Win32 Hook (intercepta ANTES de qualquer app)
        ↓
  Aplicar Filtro de Kalman
        ↓
  SetCursorPos(posição filtrada)  ← Suprimir evento original
        ↓
  Todas as aplicações recebem apenas a posição suavizada ✓
```

---

## 📊 Sugestões para o TCC

### Experimentos a realizar
1. Medir o desvio padrão do movimento com/sem filtro em usuários de teste
2. Comparar diferentes valores de `filterStrength` com um grupo de voluntários
3. Analisar a latência introduzida pelo filtro (deve ser < 5ms)

### Métricas de avaliação
- **Suavidade**: variância da trajetória do cursor
- **Precisão**: erro médio ao clicar em alvos
- **Responsividade**: latência percebida pelo usuário
- **Usabilidade**: escala SUS (System Usability Scale)

### Referências
- Kalman, R. E. (1960). "A New Approach to Linear Filtering and Prediction Problems"
- Hasan, S. S., et al. "Mouse cursor stabilization for users with motor impairments"
- Tremor suppression using Kalman filtering — IEEE Robotics

---

## ⚠️ Observações

- O software requer permissão para instalar hooks de sistema (execute normalmente, sem admin)
- Para remover do startup do Windows, desative a opção na interface ou use `msconfig`
- As configurações são salvas em `%AppData%\ParkinsonMouseAssist\settings.json`
