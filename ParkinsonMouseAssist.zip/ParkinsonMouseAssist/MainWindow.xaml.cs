using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using ParkinsonMouseAssist.Core;
using ParkinsonMouseAssist.Models;

namespace ParkinsonMouseAssist
{
    public partial class MainWindow : Window
    {
        private readonly MouseHook            _mouseHook;
        private readonly AdaptiveTremorFilter _filter;
        private readonly AppSettings          _settings;
        private readonly GlobalHotkey         _hotkey;
        private readonly DispatcherTimer      _uiTimer;

        private bool _isReady;
        private bool _mouseInCalib;   // mouse está sobre o canvas de calibração?

        // ── Posição bruta mais recente (em coordenadas de tela) ──
        // Alimentada pelo RawMouseMoved do hook, usada para o dot fantasma
        private volatile int _lastRawScreenX;
        private volatile int _lastRawScreenY;

        // ── Dados do gráfico ──
        private const int GRAPH_POINTS = 120;
        private readonly Queue<double> _rawMagnitudes      = new();
        private readonly Queue<double> _filteredMagnitudes = new();
        private int  _prevRawX, _prevRawY, _prevFiltX, _prevFiltY;
        private bool _graphInitialized;

        // ── Métricas de movimento ──
        private double _sumSpeed;
        private int    _speedSamples;
        private int    _oscillationCount;
        private double _prevMag;
        private bool   _prevWasRising;
        private long   _lastMetricsReset = Environment.TickCount64;

        public MainWindow()
        {
            try { InitializeComponent(); }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao carregar a interface:\n{ex.Message}", "Erro XAML",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                throw;
            }

            _settings  = AppSettings.Load();
            _filter    = new AdaptiveTremorFilter(_settings.FilterStrength);
            _mouseHook = new MouseHook();
            _hotkey    = new GlobalHotkey();

            ConfigureHook();
            ApplySettings();

            _uiTimer = new DispatcherTimer(DispatcherPriority.Background)
            {
                Interval = TimeSpan.FromMilliseconds(65)
            };
            _uiTimer.Tick += UiTimer_Tick;
            _uiTimer.Start();

            SourceInitialized += (_, _) => RegisterHotkey();

            Closing += (_, _) =>
            {
                _uiTimer.Stop();
                _mouseHook.Dispose();
                _hotkey.Dispose();
                _settings.Save();
            };

            _isReady = true;
        }

        // ══════════════════════════════════════════════════════
        //  Hotkey
        // ══════════════════════════════════════════════════════

        private void RegisterHotkey()
        {
            try
            {
                _hotkey.Pressed += () => Dispatcher.Invoke(() =>
                {
                    TogFilter.IsChecked = !_settings.FilterEnabled;
                });
                _hotkey.Register(this);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Não foi possível registrar Ctrl+Win:\n{ex.Message}",
                    "Aviso — Hotkey", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        // ══════════════════════════════════════════════════════
        //  Hook + filtro
        // ══════════════════════════════════════════════════════

        private void ConfigureHook()
        {
            // Captura a posição BRUTA antes de qualquer filtragem
            // Usada para exibir o dot fantasma na área de calibração
            _mouseHook.RawMouseMoved += (rx, ry) =>
            {
                _lastRawScreenX = rx;
                _lastRawScreenY = ry;
            };

            _mouseHook.FilterFunction = (rawX, rawY) =>
            {
                if (!_settings.FilterEnabled) return (rawX, rawY);

                // Durante a calibração: passa a posição bruta para a IA aprender o tremor real,
                // mas NÃO aplica o filtro no cursor — o usuário sente o tremor sem correção
                if (_filter.IsCalibrating)
                {
                    _filter.Filter(rawX, rawY); // alimenta o algoritmo mas descarta a saída
                    RecordMovement(rawX, rawY, rawX, rawY);
                    return (rawX, rawY);
                }

                var (fx, fy) = _filter.Filter(rawX, rawY);
                RecordMovement(rawX, rawY, fx, fy);
                return (fx, fy);
            };

            try
            {
                _mouseHook.Start();
                UpdateStatusText(true);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Não foi possível iniciar o hook:\n{ex.Message}",
                    "Aviso", MessageBoxButton.OK, MessageBoxImage.Warning);
                UpdateStatusText(false);
            }
        }

        private void RecordMovement(int rawX, int rawY, int filtX, int filtY)
        {
            if (!_graphInitialized)
            {
                _prevRawX = rawX; _prevRawY = rawY;
                _prevFiltX = filtX; _prevFiltY = filtY;
                _graphInitialized = true;
                return;
            }

            double rawMag = Math.Sqrt(Math.Pow(rawX - _prevRawX, 2) + Math.Pow(rawY - _prevRawY, 2));
            double filtMag = Math.Sqrt(Math.Pow(filtX - _prevFiltX, 2) + Math.Pow(filtY - _prevFiltY, 2));

            _prevRawX = rawX; _prevRawY = rawY;
            _prevFiltX = filtX; _prevFiltY = filtY;

            lock (_rawMagnitudes)
            {
                _rawMagnitudes.Enqueue(rawMag);
                if (_rawMagnitudes.Count > GRAPH_POINTS) _rawMagnitudes.Dequeue();
                _filteredMagnitudes.Enqueue(filtMag);
                if (_filteredMagnitudes.Count > GRAPH_POINTS) _filteredMagnitudes.Dequeue();
            }

            _sumSpeed += rawMag;
            _speedSamples++;

            if (_speedSamples > 1)
            {
                bool isRising = rawMag > _prevMag;
                if (_prevWasRising && !isRising) _oscillationCount++;
                _prevWasRising = isRising;
            }
            _prevMag = rawMag;
        }

        private void ApplySettings()
        {
            TogFilter.IsChecked    = _settings.FilterEnabled;
            TogAutoMode.IsChecked  = _settings.AutoMode;
            TogStartup.IsChecked   = StartupManager.IsEnabled();

            _filter.AutoMode       = _settings.AutoMode;
            _filter.FilterStrength = _settings.FilterStrength;

            SliderFilter.Value     = _settings.FilterStrength * 100.0;
            SliderFilter.IsEnabled = !_settings.AutoMode;
            BadgeAuto.Visibility   = _settings.AutoMode ? Visibility.Visible : Visibility.Collapsed;
        }

        // ══════════════════════════════════════════════════════
        //  Timer de UI
        // ══════════════════════════════════════════════════════

        private void UiTimer_Tick(object? sender, EventArgs e)
        {
            double tremorPct = _filter.DetectedTremorLevel * 100.0;
            PbTremor.Value      = tremorPct;
            TxtTremorLevel.Text = $"{tremorPct:0}%";
            TxtTremorDesc.Text  = DescribeTremorLevel(tremorPct);
            UpdateTremorBarColor(tremorPct);

            if (_settings.AutoMode)
            {
                SliderFilter.Value     = _filter.FilterStrength * 100.0;
                TxtFilterStrength.Text = $"{_filter.FilterStrength * 100:0}% (auto)";
            }

            UpdateGraph();
            UpdateMetrics(tremorPct);

            // ── Dot fantasma: mostrar posição bruta no canvas de calibração ──
            if (_mouseInCalib)
                UpdateGhostDot();
        }

        /// <summary>
        /// Converte a posição bruta de tela para coordenadas do canvas e
        /// move o GhostDot para lá, mostrando onde o cursor ESTARIA sem o filtro.
        /// </summary>
        private void UpdateGhostDot()
        {
            try
            {
                // Converter coordenadas de tela → coordenadas do canvas
                var screenPoint = new Point(_lastRawScreenX, _lastRawScreenY);
                var canvasPoint = CalibCanvas.PointFromScreen(screenPoint);

                // Verificar se está dentro dos limites do canvas
                if (canvasPoint.X >= 0 && canvasPoint.X <= CalibCanvas.ActualWidth &&
                    canvasPoint.Y >= 0 && canvasPoint.Y <= CalibCanvas.ActualHeight)
                {
                    Canvas.SetLeft(GhostDot, canvasPoint.X - GhostDot.Width  / 2);
                    Canvas.SetTop (GhostDot, canvasPoint.Y - GhostDot.Height / 2);
                    GhostDot.Visibility = Visibility.Visible;
                }
            }
            catch { /* Janela pode não estar completamente inicializada */ }
        }

        private void UpdateMetrics(double tremorPct)
        {
            long now     = Environment.TickCount64;
            long elapsed = now - _lastMetricsReset;

            if (elapsed >= 1000 && _speedSamples > 0)
            {
                double avgSpeed = _sumSpeed / _speedSamples * (1000.0 / elapsed) * 60;
                TxtAvgSpeed.Text     = $"{avgSpeed:0} px/s";
                TxtOscillations.Text = $"{_oscillationCount}/s";
                TxtStability.Text    = tremorPct switch
                {
                    < 10 => "Ótima",
                    < 30 => "Boa",
                    < 55 => "Média",
                    < 75 => "Baixa",
                    _    => "Crítica"
                };
                TxtStability.Foreground = tremorPct switch
                {
                    < 10 => new SolidColorBrush(Color.FromRgb(0xA6, 0xE3, 0xA1)),
                    < 30 => new SolidColorBrush(Color.FromRgb(0xF9, 0xE2, 0xAF)),
                    < 55 => new SolidColorBrush(Color.FromRgb(0xFA, 0xB3, 0x87)),
                    _    => new SolidColorBrush(Color.FromRgb(0xFF, 0x6B, 0x7A))
                };

                _sumSpeed = 0; _speedSamples = 0; _oscillationCount = 0;
                _lastMetricsReset = now;
            }
        }

        private void UpdateGraph()
        {
            double[] rawArr, filtArr;
            lock (_rawMagnitudes)
            {
                rawArr  = [.. _rawMagnitudes];
                filtArr = [.. _filteredMagnitudes];
            }

            if (rawArr.Length < 2) return;

            double w = TremorGraph.ActualWidth;
            double h = TremorGraph.ActualHeight;
            if (w < 10 || h < 10) return;

            double maxVal = 5.0;
            foreach (var v in rawArr) if (v > maxVal) maxVal = v;

            double midY   = h / 2.0;
            double scaleY = (h * 0.45) / maxVal;

            var rawPoints  = new PointCollection(rawArr.Length);
            var filtPoints = new PointCollection(filtArr.Length);

            for (int i = 0; i < rawArr.Length; i++)
            {
                double x = i * w / (rawArr.Length - 1);
                rawPoints.Add(new Point(x,  midY - rawArr[i]  * scaleY));
            }
            for (int i = 0; i < filtArr.Length; i++)
            {
                double x = i * w / (filtArr.Length - 1);
                filtPoints.Add(new Point(x, midY - filtArr[i] * scaleY));
            }

            TremorGraph.Points   = rawPoints;
            FilteredGraph.Points = filtPoints;
        }

        private static string DescribeTremorLevel(double pct) => pct switch
        {
            < 5  => "Nenhum tremor detectado — cursor estável",
            < 25 => "Tremor leve detectado",
            < 50 => "Tremor moderado — filtro ativo",
            < 75 => "Tremor intenso — filtro trabalhando",
            _    => "Tremor muito intenso — filtro no máximo"
        };

        private void UpdateTremorBarColor(double pct)
        {
            Color color = pct switch
            {
                < 30 => Color.FromRgb(0x8B, 0x00, 0x00),
                < 60 => Color.FromRgb(0xDC, 0x14, 0x3C),
                _    => Color.FromRgb(0xFF, 0x6B, 0x7A)
            };
            if (PbTremor.Template.FindName("PART_Indicator", PbTremor) is System.Windows.Shapes.Rectangle rect)
                rect.Fill = new SolidColorBrush(color);
        }

        // ══════════════════════════════════════════════════════
        //  Eventos dos controles
        // ══════════════════════════════════════════════════════

        private void TogFilter_Checked(object sender, RoutedEventArgs e)
        {
            if (!_isReady) return;
            _settings.FilterEnabled = true;
            _filter.Reset();
            UpdateStatusText(true);
            _settings.Save();
        }

        private void TogFilter_Unchecked(object sender, RoutedEventArgs e)
        {
            if (!_isReady) return;
            _settings.FilterEnabled = false;
            UpdateStatusText(false);
            _settings.Save();
        }

        private void TogAutoMode_Checked(object sender, RoutedEventArgs e)
        {
            if (!_isReady) return;
            _settings.AutoMode     = true;
            _filter.AutoMode       = true;
            SliderFilter.IsEnabled = false;
            BadgeAuto.Visibility   = Visibility.Visible;
            _settings.Save();
        }

        private void TogAutoMode_Unchecked(object sender, RoutedEventArgs e)
        {
            if (!_isReady) return;
            _settings.AutoMode     = false;
            _filter.AutoMode       = false;
            _filter.IsCalibrating  = false;
            SliderFilter.IsEnabled = true;
            BadgeAuto.Visibility   = Visibility.Collapsed;
            TxtFilterStrength.Text = $"{SliderFilter.Value:0}%";
            _settings.Save();
        }

        private void SliderFilter_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (!_isReady || _settings.AutoMode) return;
            double normalized        = e.NewValue / 100.0;
            _filter.FilterStrength   = normalized;
            _settings.FilterStrength = normalized;
            TxtFilterStrength.Text   = $"{e.NewValue:0}%";
            _settings.Save();
        }

        private void TogStartup_Checked(object sender, RoutedEventArgs e)
        {
            if (!_isReady) return;
            StartupManager.Enable();
            _settings.StartWithWindows = true;
            _settings.Save();
        }

        private void TogStartup_Unchecked(object sender, RoutedEventArgs e)
        {
            if (!_isReady) return;
            StartupManager.Disable();
            _settings.StartWithWindows = false;
            _settings.Save();
        }

        // ══════════════════════════════════════════════════════
        //  Área de calibração
        // ══════════════════════════════════════════════════════

        private void CalibCanvas_MouseEnter(object sender, MouseEventArgs e)
        {
            _mouseInCalib = true;

            // Ativar aprendizado da IA somente quando o mouse entrar na área
            if (_settings.AutoMode)
            {
                _filter.IsCalibrating = true;
                _filter.Reset();   // reinicia o histórico para aprender do zero nessa sessão
            }

            CalibHint.Visibility = Visibility.Collapsed;
            GhostDot.Visibility  = Visibility.Visible;

            if (_isReady)
                TxtCalibStatus.Text = "🔴 Calibrando — filtro suspenso";
        }

        private void CalibCanvas_MouseLeave(object sender, MouseEventArgs e)
        {
            _mouseInCalib = false;

            // Parar o aprendizado — manter o valor calibrado
            _filter.IsCalibrating = false;

            GhostDot.Visibility = Visibility.Collapsed;

            if (_isReady)
            {
                TxtCalibStatus.Text = $"✓ Calibrado: {_filter.FilterStrength * 100:0}%";

                // Salvar a força aprendida nas configurações
                _settings.FilterStrength = _filter.FilterStrength;
                _settings.Save();

                // Refletir no slider (visual apenas, slider fica desabilitado no modo auto)
                SliderFilter.Value = _filter.FilterStrength * 100.0;
            }
        }

        private void CalibCanvas_MouseMove(object sender, MouseEventArgs e)
        {
            // CursorDot: posição filtrada (vem do WPF, já é a posição após o hook)
            var pos = e.GetPosition(CalibCanvas);
            Canvas.SetLeft(CursorDot, pos.X - CursorDot.Width  / 2);
            Canvas.SetTop (CursorDot, pos.Y - CursorDot.Height / 2);
        }

        // ══════════════════════════════════════════════════════
        //  Janela
        // ══════════════════════════════════════════════════════

        private void TitleBar_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed) DragMove();
        }

        private void BtnMinimize_Click(object sender, RoutedEventArgs e)
            => WindowState = WindowState.Minimized;

        private void BtnClose_Click(object sender, RoutedEventArgs e)
            => Close();

        private void UpdateStatusText(bool active)
        {
            if (TxtStatus is null) return;
            TxtStatus.Text = active
                ? "● Ativo — filtrando tremor em tempo real"
                : "○ Pausado";
            TxtStatus.Foreground = active
                ? new SolidColorBrush(Color.FromRgb(0xDC, 0x14, 0x3C))
                : new SolidColorBrush(Color.FromRgb(0x7A, 0x30, 0x40));
        }
    }
}
