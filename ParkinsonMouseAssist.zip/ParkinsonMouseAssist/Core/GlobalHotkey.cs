using System;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;

namespace ParkinsonMouseAssist.Core
{
    /// <summary>
    /// Registra uma hotkey global no Windows (Ctrl + Win) para ativar/desativar
    /// o filtro mesmo quando o aplicativo está minimizado ou em segundo plano.
    ///
    /// Usa a API Win32 RegisterHotKey/UnregisterHotKey via WndProc (mensagem WM_HOTKEY).
    /// </summary>
    public sealed class GlobalHotkey : IDisposable
    {
        // ── Constantes Win32 ──
        private const int WM_HOTKEY    = 0x0312;
        private const int MOD_CONTROL  = 0x0002;
        private const int MOD_WIN      = 0x0008;
        private const int HOTKEY_ID    = 0x3A4F;   // ID arbitrário único para este app

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool RegisterHotKey(IntPtr hWnd, int id, int fsModifiers, int vk);

        [DllImport("user32.dll")]
        private static extern bool UnregisterHotKey(IntPtr hWnd, int id);

        private HwndSource? _source;
        private IntPtr      _handle;
        private bool        _registered;

        /// <summary>Disparado toda vez que Ctrl+Win é pressionado.</summary>
        public event Action? Pressed;

        /// <summary>
        /// Registra a hotkey na janela WPF informada.
        /// Deve ser chamado após a janela estar visível (SourceInitialized ou Loaded).
        /// </summary>
        public void Register(Window window)
        {
            _handle = new WindowInteropHelper(window).Handle;
            _source = HwndSource.FromHwnd(_handle);
            _source?.AddHook(WndProc);

            _registered = RegisterHotKey(_handle, HOTKEY_ID, MOD_CONTROL | MOD_WIN, 0);

            if (!_registered)
            {
                int err = Marshal.GetLastWin32Error();
                // Erro 1409 = hotkey já registrada por outro processo — não é fatal
                if (err != 1409)
                    throw new InvalidOperationException(
                        $"Não foi possível registrar a hotkey Ctrl+Win. Código de erro: {err}");
            }
        }

        private IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            if (msg == WM_HOTKEY && wParam.ToInt32() == HOTKEY_ID)
            {
                Pressed?.Invoke();
                handled = true;
            }
            return IntPtr.Zero;
        }

        public void Dispose()
        {
            if (_registered)
            {
                UnregisterHotKey(_handle, HOTKEY_ID);
                _registered = false;
            }
            _source?.RemoveHook(WndProc);
        }
    }
}
