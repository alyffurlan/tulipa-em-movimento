using Microsoft.Win32;
using System.Diagnostics;

namespace ParkinsonMouseAssist.Core
{
    /// <summary>
    /// Gerencia o início automático com o Windows via registro do sistema.
    /// Utiliza a chave HKEY_CURRENT_USER para não requerer privilégios de administrador.
    /// </summary>
    public static class StartupManager
    {
        private const string AppName    = "ParkinsonMouseAssist";
        private const string RegKeyPath = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Run";

        public static bool IsEnabled()
        {
            using var key = Registry.CurrentUser.OpenSubKey(RegKeyPath, writable: false);
            return key?.GetValue(AppName) is not null;
        }

        public static void Enable()
        {
            using var key = Registry.CurrentUser.OpenSubKey(RegKeyPath, writable: true);
            var exePath = Process.GetCurrentProcess().MainModule?.FileName;
            if (exePath is not null)
                key?.SetValue(AppName, $"\"{exePath}\"");
        }

        public static void Disable()
        {
            using var key = Registry.CurrentUser.OpenSubKey(RegKeyPath, writable: true);
            key?.DeleteValue(AppName, throwOnMissingValue: false);
        }
    }
}
