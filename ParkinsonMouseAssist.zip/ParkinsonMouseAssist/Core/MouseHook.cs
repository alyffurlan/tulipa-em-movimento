using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace ParkinsonMouseAssist.Core
{
    /// <summary>
    /// Hook de mouse de baixo nível com proteção anti-flickering.
    ///
    /// Melhorias na v2:
    ///  - Zona morta: só redireciona se diferença >= MIN_REDIRECT_PIXELS
    ///  - Throttle: limita SetCursorPos a MAX_REDIRECTS_PER_SEC por segundo
    ///  - Detecção de movimento intencional: desativa filtro temporariamente
    ///    quando o usuário faz movimentos grandes e rápidos
    /// </summary>
    public sealed class MouseHook : IDisposable
    {
        private const int  WH_MOUSE_LL   = 14;
        private const int  WM_MOUSEMOVE  = 0x0200;

        // ── Parâmetros anti-flickering ──
        private const double MIN_REDIRECT_PIXELS  = 1.5;   // zona morta mínima para redirecionar
        private const int    MAX_REDIRECTS_PER_SEC = 200;  // teto de SetCursorPos/segundo
        private const double INTENTIONAL_THRESHOLD = 30.0; // pixels: movimento voluntário grande

        [StructLayout(LayoutKind.Sequential)]
        private struct POINT { public int X; public int Y; }

        [StructLayout(LayoutKind.Sequential)]
        private struct MSLLHOOKSTRUCT
        {
            public POINT  pt;
            public uint   mouseData;
            public uint   flags;
            public uint   time;
            public IntPtr dwExtraInfo;
        }

        [DllImport("user32.dll", SetLastError = true)]
        private static extern IntPtr SetWindowsHookEx(int idHook, LowLevelMouseProc fn, IntPtr hMod, uint threadId);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool UnhookWindowsHookEx(IntPtr hhk);

        [DllImport("user32.dll")]
        private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

        [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
        private static extern IntPtr GetModuleHandle(string? lpModuleName);

        [DllImport("user32.dll")]
        private static extern bool SetCursorPos(int x, int y);

        private delegate IntPtr LowLevelMouseProc(int nCode, IntPtr wParam, IntPtr lParam);

        private IntPtr             _hookId  = IntPtr.Zero;
        private LowLevelMouseProc? _proc;
        private volatile bool      _ownMove = false;

        // ── Throttle ──
        private long _lastRedirectTick = 0;
        private readonly long _minTicksBetweenRedirects;

        // ── Posição anterior para detectar movimento intencional ──
        private int _prevRawX, _prevRawY;
        private bool _prevInitialized;

        public Func<int, int, (int X, int Y)>? FilterFunction { get; set; }
        public event Action<int, int>? RawMouseMoved;
        public bool IsActive => _hookId != IntPtr.Zero;

        public MouseHook()
        {
            _minTicksBetweenRedirects = Stopwatch.Frequency / MAX_REDIRECTS_PER_SEC;
        }

        public void Start()
        {
            if (IsActive) return;
            _proc = HookCallback;

            using var process = Process.GetCurrentProcess();
            using var module  = process.MainModule
                ?? throw new InvalidOperationException("Não foi possível obter o módulo principal.");

            _hookId = SetWindowsHookEx(WH_MOUSE_LL, _proc, GetModuleHandle(module.ModuleName), 0);

            if (_hookId == IntPtr.Zero)
                throw new InvalidOperationException(
                    $"Falha ao instalar o hook de mouse. Erro: {Marshal.GetLastWin32Error()}");
        }

        public void Stop()
        {
            if (!IsActive) return;
            UnhookWindowsHookEx(_hookId);
            _hookId = IntPtr.Zero;
        }

        private IntPtr HookCallback(int nCode, IntPtr wParam, IntPtr lParam)
        {
            if (nCode >= 0 && wParam == (IntPtr)WM_MOUSEMOVE)
            {
                // Evento gerado por nós mesmos — deixar passar
                if (_ownMove)
                {
                    _ownMove = false;
                    return CallNextHookEx(_hookId, nCode, wParam, lParam);
                }

                var info = Marshal.PtrToStructure<MSLLHOOKSTRUCT>(lParam);
                int rawX = info.pt.X;
                int rawY = info.pt.Y;

                RawMouseMoved?.Invoke(rawX, rawY);

                if (FilterFunction != null)
                {
                    // ── Detecção de movimento intencional ──
                    // Se o usuário moveu muito de uma vez, não filtrar para não travar o cursor
                    if (_prevInitialized)
                    {
                        double dx = rawX - _prevRawX;
                        double dy = rawY - _prevRawY;
                        double dist = Math.Sqrt(dx * dx + dy * dy);

                        if (dist > INTENTIONAL_THRESHOLD)
                        {
                            // Movimento grande → deixar passar sem filtro
                            _prevRawX = rawX;
                            _prevRawY = rawY;
                            return CallNextHookEx(_hookId, nCode, wParam, lParam);
                        }
                    }

                    _prevRawX = rawX;
                    _prevRawY = rawY;
                    _prevInitialized = true;

                    var (filtX, filtY) = FilterFunction(rawX, rawY);

                    // ── Zona morta: só redirecionar se houver diferença perceptível ──
                    double diffX = filtX - rawX;
                    double diffY = filtY - rawY;
                    double diff  = Math.Sqrt(diffX * diffX + diffY * diffY);

                    if (diff < MIN_REDIRECT_PIXELS)
                        return CallNextHookEx(_hookId, nCode, wParam, lParam);

                    // ── Throttle: não chamar SetCursorPos mais do que o teto ──
                    long now = Stopwatch.GetTimestamp();
                    if (now - _lastRedirectTick < _minTicksBetweenRedirects)
                        return CallNextHookEx(_hookId, nCode, wParam, lParam);

                    _lastRedirectTick = now;
                    _ownMove = true;
                    SetCursorPos(filtX, filtY);
                    return (IntPtr)1;
                }
            }

            return CallNextHookEx(_hookId, nCode, wParam, lParam);
        }

        public void Dispose() => Stop();
    }
}
