using System;

namespace ParkinsonMouseAssist.Core
{
    /// <summary>
    /// Filtro de Kalman 2D para suavização em tempo real do movimento do mouse.
    ///
    /// O Filtro de Kalman é um algoritmo de estimação ótima amplamente utilizado
    /// em sistemas de Inteligência Artificial e robótica. Ele mantém um modelo
    /// probabilístico do estado do sistema (posição e velocidade intencional do cursor)
    /// e corrige esse estado a cada nova medição ruidosa (posição com tremor).
    ///
    /// Estado: [x, y, vx, vy]  — posição e velocidade do cursor
    /// Medição: [x_raw, y_raw] — posição bruta capturada com tremor
    /// </summary>
    public class KalmanFilter2D
    {
        // ── Vetor de estado estimado: [x, y, velocidade_x, velocidade_y] ──
        private double[] _state;

        // ── Matriz de covariância do erro de estimação (4x4) ──
        private double[,] _P;

        // ── Parâmetros ajustáveis ──
        private double _processNoise;      // Q: incerteza no modelo de movimento
        private double _measurementNoise;  // R: incerteza nas medições (ruído de tremor)

        // ── Matriz de transição de estado F (modelo cinemático: posição += vel * dt) ──
        private readonly double[,] _F = new double[4, 4]
        {
            { 1, 0, 1, 0 },
            { 0, 1, 0, 1 },
            { 0, 0, 1, 0 },
            { 0, 0, 0, 1 }
        };

        // ── Matriz de observação H (medimos apenas posição, não velocidade) ──
        private readonly double[,] _H = new double[2, 4]
        {
            { 1, 0, 0, 0 },
            { 0, 1, 0, 0 }
        };

        public KalmanFilter2D(double processNoise = 0.001, double measurementNoise = 1.0)
        {
            _processNoise = processNoise;
            _measurementNoise = measurementNoise;
            _state = new double[4];
            _P = Identity(4);
            for (int i = 0; i < 4; i++) _P[i, i] = 1000.0; // Alta incerteza inicial
        }

        /// <summary>
        /// Executa um ciclo do Filtro de Kalman: Predição → Atualização.
        /// Retorna a posição filtrada (sem tremor).
        /// </summary>
        public (double X, double Y) Update(double rawX, double rawY)
        {
            // ════════════════════════════════════
            //  ETAPA 1 — PREDIÇÃO
            //  "Onde o cursor deve estar agora com base no movimento anterior?"
            // ════════════════════════════════════
            double[] xPred = MatMulVec(_F, _state);
            double[,] PPred = MatAdd(
                MatMul(MatMul(_F, _P), Transpose(_F)),
                ScalarDiag(4, _processNoise)
            );

            // ════════════════════════════════════
            //  ETAPA 2 — ATUALIZAÇÃO (CORREÇÃO)
            //  "Incorporar a nova medição (com ruído) para refinar a estimativa."
            // ════════════════════════════════════

            // Inovação: diferença entre medição real e posição prevista
            double[] innov = new double[]
            {
                rawX - xPred[0],
                rawY - xPred[1]
            };

            // Covariância da inovação: S = H * P_pred * H' + R
            double[,] S = MatAdd(
                MatMul(MatMul(_H, PPred), Transpose(_H)),
                ScalarDiag(2, _measurementNoise)
            );

            // Ganho de Kalman: K = P_pred * H' * S^(-1)
            // O ganho pondera quanto confiar na medição vs. na previsão
            double[,] K = MatMul(MatMul(PPred, Transpose(_H)), Invert2x2(S));

            // Atualizar estado: x = x_pred + K * inovação
            _state = VecAdd(xPred, MatMulVec(K, innov));

            // Atualizar covariância: P = (I - K*H) * P_pred
            _P = MatMul(MatSub(Identity(4), MatMul(K, _H)), PPred);

            return (_state[0], _state[1]);
        }

        /// <summary>Reconfigura o ruído do filtro (chamado quando o usuário ajusta a intensidade).</summary>
        public void SetNoise(double processNoise, double measurementNoise)
        {
            _processNoise = processNoise;
            _measurementNoise = measurementNoise;
        }

        /// <summary>Reinicia o filtro com uma posição conhecida.</summary>
        public void Reset(double x, double y)
        {
            _state = new double[] { x, y, 0, 0 };
            _P = Identity(4);
            for (int i = 0; i < 4; i++) _P[i, i] = 1000.0;
        }

        // ══════════════════════════════════════════════════════
        //  Funções auxiliares de álgebra linear
        // ══════════════════════════════════════════════════════

        private static double[,] MatMul(double[,] A, double[,] B)
        {
            int m = A.GetLength(0), n = B.GetLength(1), k = A.GetLength(1);
            var C = new double[m, n];
            for (int i = 0; i < m; i++)
                for (int j = 0; j < n; j++)
                    for (int p = 0; p < k; p++)
                        C[i, j] += A[i, p] * B[p, j];
            return C;
        }

        private static double[] MatMulVec(double[,] A, double[] v)
        {
            int m = A.GetLength(0), n = A.GetLength(1);
            var r = new double[m];
            for (int i = 0; i < m; i++)
                for (int j = 0; j < n; j++)
                    r[i] += A[i, j] * v[j];
            return r;
        }

        private static double[,] MatAdd(double[,] A, double[,] B)
        {
            int m = A.GetLength(0), n = A.GetLength(1);
            var C = new double[m, n];
            for (int i = 0; i < m; i++)
                for (int j = 0; j < n; j++)
                    C[i, j] = A[i, j] + B[i, j];
            return C;
        }

        private static double[,] MatSub(double[,] A, double[,] B)
        {
            int m = A.GetLength(0), n = A.GetLength(1);
            var C = new double[m, n];
            for (int i = 0; i < m; i++)
                for (int j = 0; j < n; j++)
                    C[i, j] = A[i, j] - B[i, j];
            return C;
        }

        private static double[] VecAdd(double[] a, double[] b)
        {
            var r = new double[a.Length];
            for (int i = 0; i < a.Length; i++) r[i] = a[i] + b[i];
            return r;
        }

        private static double[,] Transpose(double[,] A)
        {
            int m = A.GetLength(0), n = A.GetLength(1);
            var T = new double[n, m];
            for (int i = 0; i < m; i++)
                for (int j = 0; j < n; j++)
                    T[j, i] = A[i, j];
            return T;
        }

        private static double[,] ScalarDiag(int size, double val)
        {
            var M = new double[size, size];
            for (int i = 0; i < size; i++) M[i, i] = val;
            return M;
        }

        private static double[,] Identity(int size)
        {
            var I = new double[size, size];
            for (int i = 0; i < size; i++) I[i, i] = 1.0;
            return I;
        }

        /// <summary>Inversão analítica de matriz 2x2.</summary>
        private static double[,] Invert2x2(double[,] M)
        {
            double det = M[0, 0] * M[1, 1] - M[0, 1] * M[1, 0];
            if (Math.Abs(det) < 1e-12) det = 1e-12;
            return new double[2, 2]
            {
                {  M[1, 1] / det, -M[0, 1] / det },
                { -M[1, 0] / det,  M[0, 0] / det }
            };
        }
    }
}
