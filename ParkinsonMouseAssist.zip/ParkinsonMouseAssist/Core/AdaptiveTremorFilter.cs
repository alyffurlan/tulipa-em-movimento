using System;
using System.Collections.Generic;
using System.Linq;

namespace ParkinsonMouseAssist.Core
{
    /// <summary>
    /// Camada adaptativa de aprendizado sobre o Filtro de Kalman.
    ///
    /// Além de filtrar os tremores, este componente ajusta AUTOMATICAMENTE
    /// a intensidade do filtro com base no nível de tremor detectado em tempo real.
    /// Quando o tremor aumenta → filtro mais forte. Quando o cursor está estável
    /// ou o usuário faz movimentos rápidos e intencionais → filtro mais suave,
    /// preservando responsividade.
    /// </summary>
    public class AdaptiveTremorFilter
    {
        private readonly KalmanFilter2D _kalman;

        // Janela deslizante de histórico de deslocamentos brutos
        private readonly Queue<double> _movementHistory;
        private readonly int _historySize;

        private double _filterStrength;          // 0.0 (suave) → 1.0 (intenso)
        private double _detectedTremorLevel;     // 0.0 → 1.0
        private bool   _autoMode = true;         // IA regula automaticamente?

        /// <summary>
        /// Quando true, a IA aprende e ajusta o filtro com base no tremor atual.
        /// Quando false, mantém o último valor calibrado e para de aprender.
        /// Deve ser true APENAS enquanto o usuário move o mouse na área de calibração.
        /// </summary>
        public bool IsCalibrating { get; set; } = false;

        private double _lastRawX;
        private double _lastRawY;
        private bool   _initialized;

        // Limites para os parâmetros de ruído do Kalman
        private const double MIN_PROCESS_NOISE      = 0.00005;
        private const double MAX_PROCESS_NOISE      = 0.05;
        private const double MIN_MEASUREMENT_NOISE  = 0.5;
        private const double MAX_MEASUREMENT_NOISE  = 200.0;

        // ── Parâmetros do modo automático ──
        // O filtro automático suaviza a resposta para não oscilar bruscamente
        private const double AUTO_SMOOTH_FACTOR = 0.05;  // quão rápido o filtro acompanha o tremor
        private const double AUTO_MIN_STRENGTH  = 0.05;  // nunca desliga totalmente
        private const double AUTO_MAX_STRENGTH  = 0.98;  // teto para não travar demais o cursor

        public double DetectedTremorLevel => _detectedTremorLevel;

        public bool AutoMode
        {
            get => _autoMode;
            set => _autoMode = value;
        }

        public double FilterStrength
        {
            get => _filterStrength;
            set
            {
                _filterStrength = Math.Clamp(value, 0.0, 1.0);
                ApplyKalmanParameters();
            }
        }

        public AdaptiveTremorFilter(double filterStrength = 0.5, int historySize = 60)
        {
            _historySize = historySize;
            _movementHistory = new Queue<double>(historySize);
            _kalman = new KalmanFilter2D();
            FilterStrength = filterStrength;
        }

        /// <summary>
        /// Processa uma posição bruta do mouse e retorna a posição filtrada.
        /// </summary>
        public (int X, int Y) Filter(int rawX, int rawY)
        {
            if (!_initialized)
            {
                _kalman.Reset(rawX, rawY);
                _lastRawX = rawX;
                _lastRawY = rawY;
                _initialized = true;
                return (rawX, rawY);
            }

            double dx = rawX - _lastRawX;
            double dy = rawY - _lastRawY;
            double magnitude = Math.Sqrt(dx * dx + dy * dy);

            _movementHistory.Enqueue(magnitude);
            if (_movementHistory.Count > _historySize)
                _movementHistory.Dequeue();

            if (_movementHistory.Count >= 15)
            {
                UpdateTremorDetection();

                // ── MODO AUTOMÁTICO: IA ajusta APENAS durante a calibração ──
                if (_autoMode && IsCalibrating)
                    ApplyAutoStrength();
            }

            _lastRawX = rawX;
            _lastRawY = rawY;

            var (fx, fy) = _kalman.Update(rawX, rawY);
            return ((int)Math.Round(fx), (int)Math.Round(fy));
        }

        /// <summary>
        /// Analisa a janela de histórico para estimar o nível atual de tremor.
        /// Combina dois indicadores:
        ///   - Variância dos deslocamentos (tremor = movimentos pequenos e erráticos)
        ///   - Taxa de oscilação (tremor = mudanças de direção frequentes)
        /// </summary>
        private void UpdateTremorDetection()
        {
            var history = _movementHistory.ToArray();
            int n = history.Length;

            double mean     = history.Average();
            double variance = history.Average(m => (m - mean) * (m - mean));

            int peaks = 0;
            for (int i = 1; i < n - 1; i++)
            {
                bool isPeak = (history[i] > history[i - 1] && history[i] > history[i + 1]) ||
                              (history[i] < history[i - 1] && history[i] < history[i + 1]);
                if (isPeak) peaks++;
            }
            double oscillationRate = (double)peaks / (n - 2);

            double varianceScore    = Math.Min(1.0, variance / 80.0);
            double oscillationScore = Math.Min(1.0, oscillationRate / 0.7);
            double rawTremor        = varianceScore * 0.4 + oscillationScore * 0.6;

            // Suavizar para evitar flutuações bruscas na UI
            _detectedTremorLevel = _detectedTremorLevel * 0.85 + rawTremor * 0.15;
        }

        /// <summary>
        /// Modo automático: ajusta suavemente a força do filtro para acompanhar
        /// o nível de tremor detectado pela IA.
        ///
        /// Mapeia 0→1 de tremor para AUTO_MIN→AUTO_MAX de intensidade, com
        /// interpolação suave para evitar saltos bruscos no cursor.
        /// </summary>
        private void ApplyAutoStrength()
        {
            // Alvo: força proporcional ao tremor detectado
            double target = AUTO_MIN_STRENGTH +
                            (_detectedTremorLevel * (AUTO_MAX_STRENGTH - AUTO_MIN_STRENGTH));

            // Convergência exponencial suave (evita mudanças abruptas)
            double newStrength = _filterStrength + (_detectedTremorLevel - _filterStrength) * AUTO_SMOOTH_FACTOR;
            newStrength = Math.Clamp(newStrength, AUTO_MIN_STRENGTH, AUTO_MAX_STRENGTH);

            // Aplicar ao Kalman só se houver mudança significativa (evita chamadas desnecessárias)
            if (Math.Abs(newStrength - _filterStrength) > 0.002)
            {
                _filterStrength = newStrength;
                ApplyKalmanParameters();
            }
        }

        /// <summary>
        /// Mapeia a força do filtro (0-1) para os parâmetros do Kalman.
        /// </summary>
        private void ApplyKalmanParameters()
        {
            double t = _filterStrength;
            double processNoise     = MAX_PROCESS_NOISE * Math.Pow(MIN_PROCESS_NOISE / MAX_PROCESS_NOISE, t);
            double measurementNoise = MIN_MEASUREMENT_NOISE * Math.Pow(MAX_MEASUREMENT_NOISE / MIN_MEASUREMENT_NOISE, t);
            _kalman.SetNoise(processNoise, measurementNoise);
        }

        public void Reset()
        {
            _initialized = false;
            _movementHistory.Clear();
            _detectedTremorLevel = 0.0;
        }
    }
}

