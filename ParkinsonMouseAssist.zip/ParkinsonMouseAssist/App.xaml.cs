using System;
using System.Windows;
using System.Windows.Threading;

namespace ParkinsonMouseAssist
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            // Captura qualquer exceção não tratada e exibe ao invés de fechar silenciosamente
            DispatcherUnhandledException += (_, args) =>
            {
                MessageBox.Show(
                    $"Erro inesperado:\n\n{args.Exception.Message}\n\n{args.Exception.StackTrace}",
                    "ParkinsonMouseAssist — Erro",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
                args.Handled = true;
            };

            AppDomain.CurrentDomain.UnhandledException += (_, args) =>
            {
                MessageBox.Show(
                    $"Erro crítico:\n\n{args.ExceptionObject}",
                    "ParkinsonMouseAssist — Erro Crítico",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            };

            base.OnStartup(e);
        }
    }
}
