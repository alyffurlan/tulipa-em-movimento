using System;
using System.IO;
using System.Text.Json;

namespace ParkinsonMouseAssist.Models
{
    /// <summary>
    /// Configurações persistidas em JSON na pasta AppData do usuário.
    /// </summary>
    public class AppSettings
    {
        public double FilterStrength   { get; set; } = 0.5;
        public bool   FilterEnabled    { get; set; } = true;
        public bool   StartWithWindows { get; set; } = false;
        public bool   AutoMode         { get; set; } = true;

        // ── Caminho do arquivo de configurações ──
        private static readonly string FilePath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "ParkinsonMouseAssist",
            "settings.json");

        private static readonly JsonSerializerOptions JsonOpts = new()
        {
            WriteIndented = true
        };

        public static AppSettings Load()
        {
            try
            {
                if (File.Exists(FilePath))
                {
                    var json = File.ReadAllText(FilePath);
                    return JsonSerializer.Deserialize<AppSettings>(json) ?? new AppSettings();
                }
            }
            catch { /* Na falha, usa defaults */ }

            return new AppSettings();
        }

        public void Save()
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(FilePath)!);
                File.WriteAllText(FilePath, JsonSerializer.Serialize(this, JsonOpts));
            }
            catch { }
        }
    }
}
